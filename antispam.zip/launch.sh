#!/bin/bash

./tg -s bot.lua -p apimode --bot=503686747:AAEmLSPwXtm87C0tIp2ta6TG2d8uBeZQUAU $@


